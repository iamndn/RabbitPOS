--
-- PostgreSQL database dump
--

\restrict 8pTk7jYZbwwUL9vrdobNZGsXs2VSUdNMY0ZqdNXfHTyO9B7NypGAh0hmInlmFGX

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: categories; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.categories (
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    image_url character varying(255),
    display_order bigint DEFAULT 0,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.categories OWNER TO admin;

--
-- Name: categories_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.categories_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.categories_id_seq OWNER TO admin;

--
-- Name: categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.categories_id_seq OWNED BY public.categories.id;


--
-- Name: funds; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.funds (
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    fund_type character varying(20) DEFAULT 'cash'::character varying NOT NULL,
    current_balance numeric(12,2) DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.funds OWNER TO admin;

--
-- Name: funds_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.funds_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.funds_id_seq OWNER TO admin;

--
-- Name: funds_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.funds_id_seq OWNED BY public.funds.id;


--
-- Name: order_items; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.order_items (
    id bigint NOT NULL,
    order_id bigint NOT NULL,
    product_variant_id bigint NOT NULL,
    quantity bigint DEFAULT 1 NOT NULL,
    unit_price numeric(10,2) DEFAULT 0 NOT NULL,
    line_total numeric(10,2) DEFAULT 0 NOT NULL,
    selected_toppings jsonb DEFAULT '[]'::jsonb NOT NULL,
    toppings_price numeric(15,2) DEFAULT 0 NOT NULL,
    notes text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.order_items OWNER TO admin;

--
-- Name: order_items_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.order_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.order_items_id_seq OWNER TO admin;

--
-- Name: order_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.order_items_id_seq OWNED BY public.order_items.id;


--
-- Name: orders; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.orders (
    id bigint NOT NULL,
    order_code character varying(50) NOT NULL,
    status character varying(20) DEFAULT 'completed'::character varying NOT NULL,
    subtotal numeric(12,2) DEFAULT 0 NOT NULL,
    discount_amount numeric(12,2) DEFAULT 0 NOT NULL,
    total_amount numeric(12,2) DEFAULT 0 NOT NULL,
    fund_id bigint NOT NULL,
    created_by character varying(100) DEFAULT 'cashier'::character varying,
    cashier_id bigint,
    cashier_name character varying(100) DEFAULT ''::character varying,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    promotion_id bigint,
    promotion_discount numeric(15,2) DEFAULT 0 NOT NULL,
    shipping_fee numeric(15,2) DEFAULT 0 NOT NULL,
    platform_fee_discount numeric(15,2) DEFAULT 0 NOT NULL,
    surcharge numeric(15,2) DEFAULT 0 NOT NULL,
    cancel_reason text,
    cancelled_at timestamp with time zone,
    note text
);


ALTER TABLE public.orders OWNER TO admin;

--
-- Name: orders_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.orders_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.orders_id_seq OWNER TO admin;

--
-- Name: orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.orders_id_seq OWNED BY public.orders.id;


--
-- Name: product_variants; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.product_variants (
    id bigint NOT NULL,
    product_id bigint NOT NULL,
    variant_name character varying(100) NOT NULL,
    cogs_price numeric(10,2) DEFAULT 0 NOT NULL,
    retail_price numeric(10,2) DEFAULT 0 NOT NULL,
    sku character varying(50),
    is_active boolean DEFAULT true,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.product_variants OWNER TO admin;

--
-- Name: product_variants_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.product_variants_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.product_variants_id_seq OWNER TO admin;

--
-- Name: product_variants_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.product_variants_id_seq OWNED BY public.product_variants.id;


--
-- Name: products; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.products (
    id bigint NOT NULL,
    category_id bigint NOT NULL,
    name character varying(150) NOT NULL,
    description text,
    image_url text,
    tag character varying(20) DEFAULT 'none'::character varying,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.products OWNER TO admin;

--
-- Name: products_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.products_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.products_id_seq OWNER TO admin;

--
-- Name: products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.products_id_seq OWNED BY public.products.id;


--
-- Name: promotions; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.promotions (
    id bigint NOT NULL,
    name character varying(150) NOT NULL,
    promo_type character varying(50) NOT NULL,
    discount_value numeric(15,2) DEFAULT 0 NOT NULL,
    min_order_amount numeric(15,2) DEFAULT 0 NOT NULL,
    min_quantity bigint DEFAULT 0 NOT NULL,
    scope character varying(50) DEFAULT 'all'::character varying NOT NULL,
    target_ids jsonb DEFAULT '[]'::jsonb NOT NULL,
    gift_product_variant_id bigint,
    start_date timestamp with time zone,
    end_date timestamp with time zone,
    usage_limit bigint DEFAULT 0 NOT NULL,
    usage_count bigint DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.promotions OWNER TO admin;

--
-- Name: promotions_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.promotions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.promotions_id_seq OWNER TO admin;

--
-- Name: promotions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.promotions_id_seq OWNED BY public.promotions.id;


--
-- Name: settings; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.settings (
    key character varying(100) NOT NULL,
    value text NOT NULL,
    updated_at timestamp with time zone
);


ALTER TABLE public.settings OWNER TO admin;

--
-- Name: toppings; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.toppings (
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    price numeric(15,2) DEFAULT 0 NOT NULL,
    cogs numeric(15,2) DEFAULT 0 NOT NULL,
    category_id bigint,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.toppings OWNER TO admin;

--
-- Name: toppings_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.toppings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.toppings_id_seq OWNER TO admin;

--
-- Name: toppings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.toppings_id_seq OWNED BY public.toppings.id;


--
-- Name: transaction_categories; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.transaction_categories (
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    type character varying(20) DEFAULT 'outflow'::character varying NOT NULL,
    code character varying(50),
    is_system boolean DEFAULT false,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.transaction_categories OWNER TO admin;

--
-- Name: transaction_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.transaction_categories_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.transaction_categories_id_seq OWNER TO admin;

--
-- Name: transaction_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.transaction_categories_id_seq OWNED BY public.transaction_categories.id;


--
-- Name: transactions; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.transactions (
    id bigint NOT NULL,
    fund_id bigint NOT NULL,
    transaction_type character varying(20) DEFAULT 'outflow'::character varying NOT NULL,
    category character varying(50) DEFAULT 'other'::character varying NOT NULL,
    amount numeric(12,2) DEFAULT 0 NOT NULL,
    reference_order_id bigint,
    description text,
    created_by character varying(100) DEFAULT 'system'::character varying,
    cashier_id bigint,
    cashier_name character varying(100) DEFAULT ''::character varying,
    created_at timestamp with time zone
);


ALTER TABLE public.transactions OWNER TO admin;

--
-- Name: transactions_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.transactions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.transactions_id_seq OWNER TO admin;

--
-- Name: transactions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.transactions_id_seq OWNED BY public.transactions.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    username character varying(50) NOT NULL,
    password_hash character varying(255) NOT NULL,
    role character varying(20) DEFAULT 'staff'::character varying NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    needs_password_setup boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.users OWNER TO admin;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO admin;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: variant_groups; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.variant_groups (
    id bigint NOT NULL,
    product_id bigint NOT NULL,
    group_name character varying(100) NOT NULL,
    selection_type character varying(20) DEFAULT 'single'::character varying,
    is_required boolean DEFAULT false,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.variant_groups OWNER TO admin;

--
-- Name: variant_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.variant_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.variant_groups_id_seq OWNER TO admin;

--
-- Name: variant_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.variant_groups_id_seq OWNED BY public.variant_groups.id;


--
-- Name: categories id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.categories ALTER COLUMN id SET DEFAULT nextval('public.categories_id_seq'::regclass);


--
-- Name: funds id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.funds ALTER COLUMN id SET DEFAULT nextval('public.funds_id_seq'::regclass);


--
-- Name: order_items id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.order_items ALTER COLUMN id SET DEFAULT nextval('public.order_items_id_seq'::regclass);


--
-- Name: orders id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.orders ALTER COLUMN id SET DEFAULT nextval('public.orders_id_seq'::regclass);


--
-- Name: product_variants id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.product_variants ALTER COLUMN id SET DEFAULT nextval('public.product_variants_id_seq'::regclass);


--
-- Name: products id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.products ALTER COLUMN id SET DEFAULT nextval('public.products_id_seq'::regclass);


--
-- Name: promotions id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.promotions ALTER COLUMN id SET DEFAULT nextval('public.promotions_id_seq'::regclass);


--
-- Name: toppings id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.toppings ALTER COLUMN id SET DEFAULT nextval('public.toppings_id_seq'::regclass);


--
-- Name: transaction_categories id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.transaction_categories ALTER COLUMN id SET DEFAULT nextval('public.transaction_categories_id_seq'::regclass);


--
-- Name: transactions id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.transactions ALTER COLUMN id SET DEFAULT nextval('public.transactions_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: variant_groups id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.variant_groups ALTER COLUMN id SET DEFAULT nextval('public.variant_groups_id_seq'::regclass);


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.categories (id, name, image_url, display_order, is_active, created_at, updated_at) FROM stdin;
3	NGUYÊN CHẤT		1	t	2026-08-18 17:35:00.483778+00	2026-08-18 17:35:16.466594+00
2	TẶNG KÈM		4	t	2026-08-18 15:50:46.466905+00	2026-08-18 17:35:22.660317+00
1	MIX		2	t	2026-08-18 13:08:04.401436+00	2026-08-18 17:35:29.233015+00
\.


--
-- Data for Name: funds; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.funds (id, name, fund_type, current_balance, is_active, created_at, updated_at) FROM stdin;
2	Chuyển khoản VietQR	bank	30000.00	t	2026-08-18 13:07:23.682369+00	2026-08-18 15:54:59.262687+00
1	Tiền mặt tại quầy	cash	-14994999.00	t	2026-08-18 13:07:23.68079+00	2026-08-18 18:04:45.170547+00
\.


--
-- Data for Name: order_items; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.order_items (id, order_id, product_variant_id, quantity, unit_price, line_total, selected_toppings, toppings_price, notes, created_at, updated_at) FROM stdin;
1	1	2	1	35000.00	35000.00	[{"id": 1, "name": "Kem cheese", "price": 5000}]	5000.00	100% Đường | 100% Đá | Topping: Kem cheese	2026-08-18 13:30:32.213686+00	2026-08-18 13:30:32.213686+00
2	2	2	1	30000.00	30000.00	[]	0.00	100% Đường | 100% Đá	2026-08-18 13:31:12.973605+00	2026-08-18 13:31:12.973605+00
3	3	1	2	25000.00	50000.00	[]	0.00	Less Ice	2026-08-18 14:31:42.577945+00	2026-08-18 14:31:42.577945+00
4	4	1	2	25000.00	50000.00	[]	0.00	Less Ice	2026-08-18 14:32:13.529664+00	2026-08-18 14:32:13.529664+00
5	5	2	1	30000.00	30000.00	[]	0.00	100% Đường | 100% Đá	2026-08-18 15:45:07.329414+00	2026-08-18 15:45:07.329414+00
6	6	2	1	1.00	1.00	[]	0.00	50% Đường | 50% Đá	2026-08-18 15:52:39.461057+00	2026-08-18 15:52:39.461057+00
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.orders (id, order_code, status, subtotal, discount_amount, total_amount, fund_id, created_by, cashier_id, cashier_name, created_at, updated_at, promotion_id, promotion_discount, shipping_fee, platform_fee_discount, surcharge, cancel_reason, cancelled_at, note) FROM stdin;
1	ORD-20260818-133032-2129	completed	35000.00	10000.00	25000.00	1	Cashier Staff	3	NDN	2026-08-18 13:30:32.213076+00	2026-08-18 13:30:32.213076+00	\N	0.00	0.00	0.00	0.00	\N	\N	\N
2	ORD-20260818-133112-9732	completed	30000.00	0.00	30000.00	2	Cashier Staff	3	NDN	2026-08-18 13:31:12.97335+00	2026-08-18 13:31:12.97335+00	\N	0.00	0.00	0.00	0.00	\N	\N	\N
4	ORD-20260818-143213-5293	cancelled	50000.00	2000.00	55000.00	1	Cashier Test	1	admin	2026-08-18 14:32:13.529388+00	2026-08-18 15:49:37.132332+00	\N	10000.00	15000.00	3000.00	5000.00	Customer cancelled during Phase 3 verification	2026-08-18 14:32:13.533565+00	\N
3	ORD-20260818-143142-5769	cancelled	50000.00	2000.00	55000.00	1	Cashier Test	1	admin	2026-08-18 14:31:42.577052+00	2026-08-18 15:49:43.102385+00	\N	10000.00	15000.00	3000.00	5000.00	Customer cancelled during Phase 3 verification	2026-08-18 14:31:42.585084+00	\N
6	ORD-20260818-155239-4603	completed	1.00	0.00	1.00	1	Cashier Staff	3	NDN	2026-08-18 15:52:39.460411+00	2026-08-18 15:52:39.460411+00	1	0.00	0.00	0.00	0.00		\N	\N
5	ORD-20260818-154507-3287	cancelled	30000.00	0.00	31100.00	1	Cashier Staff	3	NDN	2026-08-18 15:45:07.328867+00	2026-08-18 16:05:49.443904+00	\N	10000.00	15000.00	8900.00	5000.00	d	2026-08-18 16:05:49.44342+00	\N
\.


--
-- Data for Name: product_variants; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.product_variants (id, product_id, variant_name, cogs_price, retail_price, sku, is_active, created_at, updated_at) FROM stdin;
1	1	Size M	8000.00	25000.00		t	2026-08-18 13:08:34.375196+00	2026-08-18 13:08:34.375196+00
2	1	Size L	10000.00	30000.00		t	2026-08-18 13:08:34.375196+00	2026-08-18 13:08:34.375196+00
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.products (id, category_id, name, description, image_url, tag, is_active, created_at, updated_at) FROM stdin;
1	1	LÊ + LỰU			none	t	2026-08-18 13:08:34.374333+00	2026-08-18 13:08:34.374333+00
\.


--
-- Data for Name: promotions; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.promotions (id, name, promo_type, discount_value, min_order_amount, min_quantity, scope, target_ids, gift_product_variant_id, start_date, end_date, usage_limit, usage_count, is_active, created_at, updated_at) FROM stdin;
1	Khai Truong Giam 10K	discount_amount	10000.00	30000.00	1	all	[]	\N	\N	\N	100	1	t	2026-08-18 14:31:09.392802+00	2026-08-18 15:52:39.461704+00
\.


--
-- Data for Name: settings; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.settings (key, value, updated_at) FROM stdin;
vietqr_account_name	THO JUICE AND COFFEE	2026-08-18 23:59:22.162465+00
store_phone	0901234567	2026-08-18 23:59:22.162465+00
currency_symbol	đ	2026-08-18 23:59:22.162465+00
currency_position	suffix	2026-08-18 23:59:22.162465+00
currency_code	VND	2026-08-18 23:59:22.162465+00
vietqr_bank_id	MB	2026-08-18 23:59:22.162465+00
vietqr_account_no	123456789	2026-08-18 23:59:22.162465+00
store_name	Thỏ Juice & Coffee	2026-08-18 23:59:22.162465+00
store_address	123 Vo Van Kiet, D1, HCMC	2026-08-18 23:59:22.162465+00
store_logo_url	/uploads/1787097559420050236_cbe3f588bbf07b46.png	2026-08-18 23:59:22.162465+00
\.


--
-- Data for Name: toppings; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.toppings (id, name, price, cogs, category_id, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: transaction_categories; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.transaction_categories (id, name, type, code, is_system, created_at, updated_at) FROM stdin;
1	Mua nguyên liệu	outflow	ingredient_purchase	t	2026-08-18 17:03:47.302006+00	2026-08-18 17:03:47.302006+00
2	Chi phí vận hành	outflow	utility_bill	t	2026-08-18 17:03:47.303093+00	2026-08-18 17:03:47.303093+00
3	Chi phí khác	outflow	other	t	2026-08-18 17:03:47.30401+00	2026-08-18 17:03:47.30401+00
4	Doanh thu bán hàng	inflow	sale	t	2026-08-18 17:03:47.304894+00	2026-08-18 17:03:47.304894+00
5	Thu nhập khác	inflow	other	t	2026-08-18 17:03:47.305741+00	2026-08-18 17:03:47.305741+00
6	Chênh lệch đối soát	both	reconciliation_variance	t	2026-08-18 17:03:47.30657+00	2026-08-18 17:03:47.30657+00
\.


--
-- Data for Name: transactions; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.transactions (id, fund_id, transaction_type, category, amount, reference_order_id, description, created_by, cashier_id, cashier_name, created_at) FROM stdin;
1	1	inflow	sale	25000.00	1	POS Sale Order: ORD-20260818-133032-2129	Cashier Staff	3	NDN	2026-08-18 13:30:32.214335+00
2	2	inflow	sale	30000.00	2	POS Sale Order: ORD-20260818-133112-9732	Cashier Staff	3	NDN	2026-08-18 13:31:12.973949+00
3	1	outflow	ingredient_purchase	20000.00	\N	2 túi đá	Manager	3	NDN	2026-08-18 14:01:48.851928+00
4	1	inflow	sale	55000.00	3	POS Sale Order: ORD-20260818-143142-5769	Cashier Test	1	admin	2026-08-18 14:31:42.578915+00
5	1	outflow	other	55000.00	3	Hoàn tiền đơn hàng #ORD-20260818-143142-5769 - Lý do: Customer cancelled during Phase 3 verification	admin	1	admin	2026-08-18 14:31:42.585712+00
6	1	inflow	sale	55000.00	4	POS Sale Order: ORD-20260818-143213-5293	Cashier Test	1	admin	2026-08-18 14:32:13.530052+00
7	1	outflow	other	55000.00	4	Hoàn tiền đơn hàng #ORD-20260818-143213-5293 - Lý do: Customer cancelled during Phase 3 verification	admin	1	admin	2026-08-18 14:32:13.534013+00
8	1	inflow	sale	31100.00	5	POS Sale Order: ORD-20260818-154507-3287	Cashier Staff	3	NDN	2026-08-18 15:45:07.330106+00
9	1	inflow	sale	1.00	6	POS Sale Order: ORD-20260818-155239-4603	Cashier Staff	3	NDN	2026-08-18 15:52:39.461986+00
10	1	outflow	other	31100.00	5	Hoàn tiền đơn hàng #ORD-20260818-154507-3287 - Lý do: d	NDN	3	NDN	2026-08-18 16:05:49.444296+00
11	1	outflow	Tiền thuê mặt bằng & kiosk	5000000.00	\N	Thanh toán tiền thuê mặt bằng tháng 8	admin	1	admin	2026-08-18 17:04:02.009958+00
13	1	outflow	Tiền thuê mặt bằng & kiosk	5000000.00	\N	Thanh toán tiền thuê mặt bằng tháng 8	admin	1	admin	2026-08-18 17:18:04.245901+00
15	1	outflow	Tiền thuê mặt bằng & kiosk	5000000.00	\N	Thanh toán tiền thuê mặt bằng tháng 8	admin	1	admin	2026-08-18 18:04:45.170328+00
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.users (id, username, password_hash, role, is_active, needs_password_setup, created_at, updated_at) FROM stdin;
4	NHUNG	$2a$10$tGEVlq8KZsomWuh568SqU.13Glzqo8hPbAEJ8uSeeQAWPQbpP6u3W	admin	t	t	2026-08-18 13:07:23.627689+00	2026-08-18 13:07:23.627689+00
5	DAT	$2a$10$XPn6LUuSDquVmJkGk/HySuhLID7IZrpAis31P1qPkoS96LFSzr2Su	admin	t	t	2026-08-18 13:07:23.678787+00	2026-08-18 13:07:23.678787+00
1	admin	$2a$10$eZToUm7JMonwloLo/QlkSeW/dYUSk9GDM5QXD09iHe.V3EdBvB.0y	admin	t	f	2026-08-18 13:07:23.394631+00	2026-08-19 00:12:13.22916+00
2	staff	$2a$10$G9r5GyDX0Exo6gr.vW10YeJvgNzRTeDz2OZpa2lQkeYO730F.Aip6	staff	t	t	2026-08-18 13:07:23.518573+00	2026-08-19 00:12:13.281609+00
3	NDN	$2a$10$8JLc/fIfPZdNNu3/H.I6heD4P8ln.MTn9QTFNv6lVpxyNv5SK/3NS	admin	t	f	2026-08-18 13:07:23.574245+00	2026-08-19 00:17:51.589431+00
\.


--
-- Data for Name: variant_groups; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.variant_groups (id, product_id, group_name, selection_type, is_required, created_at, updated_at) FROM stdin;
\.


--
-- Name: categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.categories_id_seq', 3, true);


--
-- Name: funds_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.funds_id_seq', 2, true);


--
-- Name: order_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.order_items_id_seq', 6, true);


--
-- Name: orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.orders_id_seq', 6, true);


--
-- Name: product_variants_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.product_variants_id_seq', 2, true);


--
-- Name: products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.products_id_seq', 1, true);


--
-- Name: promotions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.promotions_id_seq', 4, true);


--
-- Name: toppings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.toppings_id_seq', 1, true);


--
-- Name: transaction_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.transaction_categories_id_seq', 9, true);


--
-- Name: transactions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.transactions_id_seq', 15, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.users_id_seq', 5, true);


--
-- Name: variant_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.variant_groups_id_seq', 1, false);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: funds funds_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.funds
    ADD CONSTRAINT funds_pkey PRIMARY KEY (id);


--
-- Name: order_items order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_pkey PRIMARY KEY (id);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: product_variants product_variants_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.product_variants
    ADD CONSTRAINT product_variants_pkey PRIMARY KEY (id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: promotions promotions_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.promotions
    ADD CONSTRAINT promotions_pkey PRIMARY KEY (id);


--
-- Name: settings settings_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_pkey PRIMARY KEY (key);


--
-- Name: toppings toppings_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.toppings
    ADD CONSTRAINT toppings_pkey PRIMARY KEY (id);


--
-- Name: transaction_categories transaction_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.transaction_categories
    ADD CONSTRAINT transaction_categories_pkey PRIMARY KEY (id);


--
-- Name: transactions transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: variant_groups variant_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.variant_groups
    ADD CONSTRAINT variant_groups_pkey PRIMARY KEY (id);


--
-- Name: idx_categories_display_order; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_categories_display_order ON public.categories USING btree (display_order);


--
-- Name: idx_categories_is_active; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_categories_is_active ON public.categories USING btree (is_active);


--
-- Name: idx_funds_is_active; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_funds_is_active ON public.funds USING btree (is_active);


--
-- Name: idx_order_items_order_id; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_order_items_order_id ON public.order_items USING btree (order_id);


--
-- Name: idx_order_items_product_variant_id; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_order_items_product_variant_id ON public.order_items USING btree (product_variant_id);


--
-- Name: idx_orders_cashier_id; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_orders_cashier_id ON public.orders USING btree (cashier_id);


--
-- Name: idx_orders_fund_id; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_orders_fund_id ON public.orders USING btree (fund_id);


--
-- Name: idx_orders_order_code; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX idx_orders_order_code ON public.orders USING btree (order_code);


--
-- Name: idx_orders_promotion_id; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_orders_promotion_id ON public.orders USING btree (promotion_id);


--
-- Name: idx_orders_status; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_orders_status ON public.orders USING btree (status);


--
-- Name: idx_product_variants_product_id; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_product_variants_product_id ON public.product_variants USING btree (product_id);


--
-- Name: idx_product_variants_sku; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_product_variants_sku ON public.product_variants USING btree (sku);


--
-- Name: idx_products_category_id; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_products_category_id ON public.products USING btree (category_id);


--
-- Name: idx_products_is_active; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_products_is_active ON public.products USING btree (is_active);


--
-- Name: idx_promotions_end_date; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_promotions_end_date ON public.promotions USING btree (end_date);


--
-- Name: idx_promotions_gift_product_variant_id; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_promotions_gift_product_variant_id ON public.promotions USING btree (gift_product_variant_id);


--
-- Name: idx_promotions_is_active; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_promotions_is_active ON public.promotions USING btree (is_active);


--
-- Name: idx_promotions_start_date; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_promotions_start_date ON public.promotions USING btree (start_date);


--
-- Name: idx_toppings_category_id; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_toppings_category_id ON public.toppings USING btree (category_id);


--
-- Name: idx_toppings_is_active; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_toppings_is_active ON public.toppings USING btree (is_active);


--
-- Name: idx_transaction_categories_type; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_transaction_categories_type ON public.transaction_categories USING btree (type);


--
-- Name: idx_transactions_cashier_id; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_transactions_cashier_id ON public.transactions USING btree (cashier_id);


--
-- Name: idx_transactions_fund_id; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_transactions_fund_id ON public.transactions USING btree (fund_id);


--
-- Name: idx_transactions_reference_order_id; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_transactions_reference_order_id ON public.transactions USING btree (reference_order_id);


--
-- Name: idx_users_username; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX idx_users_username ON public.users USING btree (username);


--
-- Name: idx_variant_groups_product_id; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_variant_groups_product_id ON public.variant_groups USING btree (product_id);


--
-- Name: order_items fk_order_items_variant; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT fk_order_items_variant FOREIGN KEY (product_variant_id) REFERENCES public.product_variants(id);


--
-- Name: orders fk_orders_fund; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT fk_orders_fund FOREIGN KEY (fund_id) REFERENCES public.funds(id);


--
-- Name: order_items fk_orders_items; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT fk_orders_items FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: orders fk_orders_promotion; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT fk_orders_promotion FOREIGN KEY (promotion_id) REFERENCES public.promotions(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: products fk_products_category; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT fk_products_category FOREIGN KEY (category_id) REFERENCES public.categories(id) ON DELETE CASCADE;


--
-- Name: variant_groups fk_products_variant_groups; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.variant_groups
    ADD CONSTRAINT fk_products_variant_groups FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: product_variants fk_products_variants; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.product_variants
    ADD CONSTRAINT fk_products_variants FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: promotions fk_promotions_gift_variant; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.promotions
    ADD CONSTRAINT fk_promotions_gift_variant FOREIGN KEY (gift_product_variant_id) REFERENCES public.product_variants(id);


--
-- Name: transactions fk_transactions_fund; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT fk_transactions_fund FOREIGN KEY (fund_id) REFERENCES public.funds(id);


--
-- Name: transactions fk_transactions_reference_order; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT fk_transactions_reference_order FOREIGN KEY (reference_order_id) REFERENCES public.orders(id);


--
-- Name: toppings toppings_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.toppings
    ADD CONSTRAINT toppings_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict 8pTk7jYZbwwUL9vrdobNZGsXs2VSUdNMY0ZqdNXfHTyO9B7NypGAh0hmInlmFGX

